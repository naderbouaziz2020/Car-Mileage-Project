-- PROCEDURE p_DisplayAllEmpWithGivenRole **********************************************************

create or replace PROCEDURE p_DisplayAllEmpWithGivenRole
(P_ROLE INT)
AS
    CURSOR ProcCur IS SELECT EmpID, Name, StreetName  FROM employee e 
    JOIN Location l
    on e.LocID = l.LocID
    WHERE ROLEID = P_ROLE;
    V_EMPID INT;
    V_EMPNAME VARCHAR2(20);
    V_LOCADDRESS VARCHAR2(20);
    V_ROLENAME VARCHAR2(20);
    v_locid INT;
BEGIN
    SELECT  RoleName INTO  V_ROLENAME from Role where RoleID = P_ROLE;
    dbms_output.put_line ('===================================================');
    dbms_output.put_line ('Below list shows all employees with role "' || V_ROLENAME || '":');
    dbms_output.put_line ('===================================================');
    OPEN ProcCur;
    LOOP
        FETCH ProcCur INTO V_EMPID, V_EMPNAME, V_LOCADDRESS;
        EXIT WHEN ProcCur%NOTFOUND;
        dbms_output.put_line('Employee ID: ' || V_EMPID  || '; ' || V_EMPNAME || ';  Location address: ' || V_LOCADDRESS );
    END LOOP;
    CLOSE ProcCur;
END;


-- PROCEDURE P_UpdateActivityLog  **********************************************************



create or replace PROCEDURE P_UpdateActivityLog
(V_Operation VARCHAR2,
V_tableName VARCHAR2)
AS
v_timestamp timestamp;
BEGIN
    select SYSTIMESTAMP AT TIME ZONE 'UTC' into v_timestamp FROM DUAL ;
    INSERT INTO ActivityLog (DATETIMESTAMP, USERNAME, ACTIVITYTYPE, TABLENAME) 
    VALUES (v_timestamp, USER, V_Operation, V_tableName );
END;



-- PROCEDURE P_UPDATERESTAURANTDATA  **********************************************************


create or replace PROCEDURE P_UPDATERESTAURANTDATA

AS
EmpN int; 
CarN int; 
LocN int;
BEGIN

	SELECT COUNT(1) into EmpN FROM Employee;
	SELECT COUNT(1) into CarN FROM car;
	SELECT COUNT(1) into LocN FROM Location;
	UPDATE Restaurant SET EmpNumber = EmpN , CarNumber = CarN, LocationNumber = LocN WHERE RestID = 1;
	dbms_output.put_line('Table Restaurant Updated');
END;

-- Test procedure P_UPDATERESTAURANTDATA :

-- SELECT * FROM RESTAURANT;
-- 
-- INSERT INTO Location (LocID, RestID, StreetName, StreetNumber, PostalCode, City, Phone, StatusID) 
--		VALUES (4, 1, N'Kolejowa', N'7', N'01-789', N'Warsaw', N'+48 963 852 741', 1);
-- EXEC P_UPDATERESTAURANTDATA;
-- SELECT * FROM RESTAURANT;
--
--
-- DELETE FROM RESTAURANT WHERE LOCID  = 4;
-- EXEC P_UPDATERESTAURANTDATA;
-- SELECT * FROM RESTAURANT;
