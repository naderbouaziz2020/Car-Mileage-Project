-- ActionType TABLE ****************************************************************

INSERT INTO ActionType (ActionID, Description) VALUES (1, N'Change Tires');

INSERT INTO ActionType (ActionID, Description) VALUES (2, N'Change Oil');

INSERT INTO ActionType (ActionID, Description) VALUES (3, N'Replacing the Brake Pads');

INSERT INTO ActionType (ActionID, Description) VALUES (4, N'Changing the Brake Fluid');

INSERT INTO ActionType (ActionID, Description) VALUES (5, N'Change windshield wipers');

INSERT INTO ActionType (ActionID, Description) VALUES (6, N'Change air filters');

INSERT INTO ActionType (ActionID, Description) VALUES (7, N'Reserve Tech Inspection visit at car service');

-- CarHistoryStatus TABLE ****************************************************************

INSERT INTO CarHistoryStatus (StatusID, StatusName) VALUES (1, N'In progress');

INSERT INTO CarHistoryStatus (StatusID, StatusName) VALUES (2, N'Completed');

INSERT INTO CarHistoryStatus (StatusID, StatusName) VALUES (3, N'Canceled');

-- PaymentCycle TABLE ****************************************************************

INSERT INTO PaymentCycle (PaymentCycleID, PaymentCycle) VALUES (N'C', N'Commission');

INSERT INTO PaymentCycle (PaymentCycleID, PaymentCycle) VALUES (N'H', N'Hourly');

INSERT INTO PaymentCycle (PaymentCycleID, PaymentCycle) VALUES (N'M', N'Monthly');

INSERT INTO PaymentCycle (PaymentCycleID, PaymentCycle) VALUES (N'Q', N'Quarterly');

-- Role TABLE ****************************************************************

INSERT INTO Role (RoleID, RoleName) VALUES (1, N'Manager');

INSERT INTO Role (RoleID, RoleName) VALUES (2, N'Cook');

INSERT INTO Role (RoleID, RoleName) VALUES (3, N'Driver');

INSERT INTO Role (RoleID, RoleName) VALUES (4, N'Cashier');

-- Role Status ****************************************************************


INSERT INTO Status (StatusID, StatusName) VALUES (0, N'Inactive');

INSERT INTO Status (StatusID, StatusName) VALUES (1, N'Active');

-- Role ContractType ****************************************************************


INSERT INTO ContractType (ContractTypeID, ContractType) VALUES (1, N'Employment');

INSERT INTO ContractType (ContractTypeID, ContractType) VALUES (2, N'Civil Contract');


-- Role Restaurant ****************************************************************

INSERT INTO Restaurant (RestID, Name, EmpNumber, CarNumber, LocationNumber, Website, Email, Phone) VALUES (1, N'Burger Warsaw', 0, 0, 0, N'www.burger.com', N'contact@burger.com', N'+48 123 456 789');

-- Role Location ****************************************************************

INSERT INTO Location (LocID, RestID, StreetName, StreetNumber, PostalCode, City, Phone, StatusID) VALUES (1, 1, N'Gara�owa', N'9', N'01-123', N'Warsaw', N'+48 987 654 321', 1);

INSERT INTO Location (LocID, RestID, StreetName, StreetNumber, PostalCode, City, Phone, StatusID) VALUES (2, 1, N'Plac Wilsona', N'5', N'01-456', N'Warsaw', N'+48 456 123 789', 1);

INSERT INTO Location (LocID, RestID, StreetName, StreetNumber, PostalCode, City, Phone, StatusID) VALUES (3, 1, N'Kolejowa', N'7', N'01-789', N'Warsaw', N'+48 963 852 741', 1);

-- Role Employee ****************************************************************


INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (1, N'Spider Man', 3, 1, CAST(N'2017-05-10' AS Date), NULL,  CAST(3200.00 AS Numeric(10, 2)), 1, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (2, N'Iron Man', 2, 1, CAST(N'2017-03-01' AS Date), NULL, CAST(8000.00 AS Numeric(10, 2)), 1, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (3, N'Natasha Romanoff', 4, 2, CAST(N'2017-04-16' AS Date), CAST(N'2017-10-16' AS Date), CAST(25.00 AS Numeric(10, 2)), 1, N'H', 0);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (4, N'Black Panther', 1, 1, CAST(N'2017-03-01' AS Date), NULL, CAST(10406.00 AS Numeric(10, 2)), 1, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (5, N'Doctor Strange', 3, 2, CAST(N'2018-05-10' AS Date), CAST(N'2022-02-01' AS Date), CAST(19.70 AS Numeric(10, 2)), 1, N'H', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (6, N'Wolverin', 2, 2, CAST(N'2020-09-01' AS Date), CAST(N'2022-04-05' AS Date), CAST(30.00 AS Numeric(10, 2)), 3, N'H', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (7, N'Captan America', 3, 2, CAST(N'2020-05-10' AS Date), CAST(N'2022-08-22' AS Date), CAST(20.00 AS Numeric(10, 2)), 3, N'H', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (8, N'Black Widow', 1, 1, CAST(N'2019-03-01' AS Date), NULL, CAST(10406.00 AS Numeric(10, 2)), 3, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (9, N'Winter Soldier', 4, 1, CAST(N'2019-08-10' AS Date), NULL, CAST(4000.00 AS Numeric(10, 2)), 3, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (10, N'Jessica Jones', 3, 2, CAST(N'2019-03-01' AS Date), CAST(N'2019-09-03' AS Date), CAST(19.70 AS Numeric(10, 2)), 3, N'H', 0);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (11, N'Ant Man', 1, 1, CAST(N'2021-05-10' AS Date), NULL, CAST(10406.00 AS Numeric(10, 2)), 2, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (12, N'Deadpool', 2, 2, CAST(N'2021-09-01' AS Date), CAST(N'2022-06-01' AS Date), CAST(30.00 AS Numeric(10, 2)), 2, N'H', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (13, N'Luke Cage', 4, 1, CAST(N'2021-05-10' AS Date), NULL, CAST(7000.00 AS Numeric(10, 2)), 2, N'M', 1);

INSERT INTO Employee (EmpID, Name, RoleID, ContractTypeID, StartContract, EndContract, UnitSalary, LocID, PaymentCycleID, StatusID) 
        VALUES (14, N'Green blin', 3, 2, CAST(N'2021-09-01' AS Date), CAST(N'2022-06-01' AS Date), CAST(19.70 AS Numeric(10, 2)), 2, N'H', 1);



-- Role Car ****************************************************************



INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (1, 1, N'Toyota', N'Ay', N'WZ458WZ', CAST(N'2017-03-09' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2020-01-26' AS Date), 0);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (2, 1, N'Toyota', N'Ay', N'PL899WZ', CAST(N'2017-10-11' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2020-10-11' AS Date), 0);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (3, 1, N'Toyota', N'Ay', N'LK741WZ', CAST(N'2018-05-15' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2021-06-22' AS Date), 1);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (4, 1, N'Toyota', N'Ay', N'YU887WZ', CAST(N'2020-04-23' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2023-01-26' AS Date), 1);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (5, 1, N'Toyota', N'Ay', N'NM265WZ', CAST(N'2020-12-28' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2023-09-19' AS Date), 1);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (6, 1, N'Toyota', N'Ay', N'XC499WZ', CAST(N'2021-07-13' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2024-10-01' AS Date), 1);

INSERT INTO Car (CarID, RestID, Brand, Model, RegistrationNumber, StartUse, CounterLimit, CounterCycleTechInspect, CounterCycleTechInspectOffset, PlannedDiagnostics, StatusID) 
        VALUES (7, 1, N'Toyota', N'Ay', N'OP963WZ', CAST(N'2021-12-26' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2024-06-30' AS Date), 1);


-- Role CarMileage ****************************************************************

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2020-12-29' AS Date), CAST(7 AS Numeric(20, 0)), CAST(120 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2020-12-30' AS Date), CAST(120 AS Numeric(20, 0)), CAST(188 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2020-12-31' AS Date), CAST(188 AS Numeric(20, 0)), CAST(238 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-01' AS Date), CAST(238 AS Numeric(20, 0)), CAST(238 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-01-02' AS Date), CAST(238 AS Numeric(20, 0)), CAST(306 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-03' AS Date), CAST(306 AS Numeric(20, 0)), CAST(413 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-04' AS Date), CAST(413 AS Numeric(20, 0)), CAST(510 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-05' AS Date), CAST(510 AS Numeric(20, 0)), CAST(626 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-01-06' AS Date), CAST(626 AS Numeric(20, 0)), CAST(735 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-07' AS Date), CAST(735 AS Numeric(20, 0)), CAST(847 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-08' AS Date), CAST(847 AS Numeric(20, 0)), CAST(952 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-09' AS Date), CAST(952 AS Numeric(20, 0)), CAST(952 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-01-10' AS Date), CAST(952 AS Numeric(20, 0)), CAST(1050 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-11' AS Date), CAST(1050 AS Numeric(20, 0)), CAST(1134 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-12' AS Date), CAST(1134 AS Numeric(20, 0)), CAST(1235 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-13' AS Date), CAST(1235 AS Numeric(20, 0)), CAST(1345 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-14' AS Date), CAST(1345 AS Numeric(20, 0)), CAST(1474 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-01-15' AS Date), CAST(1474 AS Numeric(20, 0)), CAST(1536 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-01-16' AS Date), CAST(1536 AS Numeric(20, 0)), CAST(1634 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-17' AS Date), CAST(1634 AS Numeric(20, 0)), CAST(1740 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-18' AS Date), CAST(1740 AS Numeric(20, 0)), CAST(1842 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-19' AS Date), CAST(1842 AS Numeric(20, 0)), CAST(1977 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-01-20' AS Date), CAST(1977 AS Numeric(20, 0)), CAST(2110 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-21' AS Date), CAST(2110 AS Numeric(20, 0)), CAST(2191 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-22' AS Date), CAST(2191 AS Numeric(20, 0)), CAST(2312 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-23' AS Date), CAST(2312 AS Numeric(20, 0)), CAST(2397 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-01-24' AS Date), CAST(2397 AS Numeric(20, 0)), CAST(2500 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-25' AS Date), CAST(2500 AS Numeric(20, 0)), CAST(2632 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-26' AS Date), CAST(2632 AS Numeric(20, 0)), CAST(2737 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-27' AS Date), CAST(2737 AS Numeric(20, 0)), CAST(2837 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-01-28' AS Date), CAST(2837 AS Numeric(20, 0)), CAST(2961 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-01-29' AS Date), CAST(2961 AS Numeric(20, 0)), CAST(3039 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-01-30' AS Date), CAST(3039 AS Numeric(20, 0)), CAST(3146 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-01-31' AS Date), CAST(3146 AS Numeric(20, 0)), CAST(3252 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-01' AS Date), CAST(3252 AS Numeric(20, 0)), CAST(3357 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-02-02' AS Date), CAST(3357 AS Numeric(20, 0)), CAST(3471 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-02-03' AS Date), CAST(3471 AS Numeric(20, 0)), CAST(3594 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-04' AS Date), CAST(3594 AS Numeric(20, 0)), CAST(3720 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-05' AS Date), CAST(3720 AS Numeric(20, 0)), CAST(3794 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-06' AS Date), CAST(3794 AS Numeric(20, 0)), CAST(3932 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-02-07' AS Date), CAST(3932 AS Numeric(20, 0)), CAST(4045 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-08' AS Date), CAST(4045 AS Numeric(20, 0)), CAST(4162 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-09' AS Date), CAST(4162 AS Numeric(20, 0)), CAST(4270 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-10' AS Date), CAST(4270 AS Numeric(20, 0)), CAST(4373 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-02-11' AS Date), CAST(4373 AS Numeric(20, 0)), CAST(4470 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-12' AS Date), CAST(4470 AS Numeric(20, 0)), CAST(4609 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-13' AS Date), CAST(4609 AS Numeric(20, 0)), CAST(4749 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-14' AS Date), CAST(4749 AS Numeric(20, 0)), CAST(4874 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-02-15' AS Date), CAST(4874 AS Numeric(20, 0)), CAST(4972 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-16' AS Date), CAST(4972 AS Numeric(20, 0)), CAST(5115 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-17' AS Date), CAST(5115 AS Numeric(20, 0)), CAST(5217 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-18' AS Date), CAST(5217 AS Numeric(20, 0)), CAST(5347 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-19' AS Date), CAST(5347 AS Numeric(20, 0)), CAST(5486 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-02-20' AS Date), CAST(5486 AS Numeric(20, 0)), CAST(5581 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-02-21' AS Date), CAST(5581 AS Numeric(20, 0)), CAST(5683 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-22' AS Date), CAST(5683 AS Numeric(20, 0)), CAST(5774 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-23' AS Date), CAST(5774 AS Numeric(20, 0)), CAST(5834 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-24' AS Date), CAST(5834 AS Numeric(20, 0)), CAST(5919 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-02-25' AS Date), CAST(5919 AS Numeric(20, 0)), CAST(6012 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-02-26' AS Date), CAST(6012 AS Numeric(20, 0)), CAST(6132 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-02-27' AS Date), CAST(6132 AS Numeric(20, 0)), CAST(6250 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-02-28' AS Date), CAST(6250 AS Numeric(20, 0)), CAST(6370 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-03-01' AS Date), CAST(6370 AS Numeric(20, 0)), CAST(6468 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-02' AS Date), CAST(6468 AS Numeric(20, 0)), CAST(6577 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-03' AS Date), CAST(6577 AS Numeric(20, 0)), CAST(6703 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-04' AS Date), CAST(6703 AS Numeric(20, 0)), CAST(6786 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-03-05' AS Date), CAST(6786 AS Numeric(20, 0)), CAST(6950 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-06' AS Date), CAST(6950 AS Numeric(20, 0)), CAST(7014 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-07' AS Date), CAST(7014 AS Numeric(20, 0)), CAST(7081 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-08' AS Date), CAST(7081 AS Numeric(20, 0)), CAST(7141 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-09' AS Date), CAST(7141 AS Numeric(20, 0)), CAST(7212 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-03-10' AS Date), CAST(7212 AS Numeric(20, 0)), CAST(7332 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-03-11' AS Date), CAST(7332 AS Numeric(20, 0)), CAST(7472 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-12' AS Date), CAST(7472 AS Numeric(20, 0)), CAST(7605 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-13' AS Date), CAST(7605 AS Numeric(20, 0)), CAST(7698 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-14' AS Date), CAST(7698 AS Numeric(20, 0)), CAST(7814 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-03-15' AS Date), CAST(7814 AS Numeric(20, 0)), CAST(7888 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-16' AS Date), CAST(7888 AS Numeric(20, 0)), CAST(7996 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-17' AS Date), CAST(7996 AS Numeric(20, 0)), CAST(8115 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-18' AS Date), CAST(8115 AS Numeric(20, 0)), CAST(8230 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-03-19' AS Date), CAST(8230 AS Numeric(20, 0)), CAST(8373 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-20' AS Date), CAST(8373 AS Numeric(20, 0)), CAST(8503 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-21' AS Date), CAST(8503 AS Numeric(20, 0)), CAST(8590 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-22' AS Date), CAST(8590 AS Numeric(20, 0)), CAST(8677 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-03-23' AS Date), CAST(8677 AS Numeric(20, 0)), CAST(8798 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-24' AS Date), CAST(8798 AS Numeric(20, 0)), CAST(8927 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-25' AS Date), CAST(8927 AS Numeric(20, 0)), CAST(9085 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-26' AS Date), CAST(9085 AS Numeric(20, 0)), CAST(9214 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-03-27' AS Date), CAST(9214 AS Numeric(20, 0)), CAST(9352 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-03-28' AS Date), CAST(9352 AS Numeric(20, 0)), CAST(9467 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-03-29' AS Date), CAST(9467 AS Numeric(20, 0)), CAST(9560 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-03-30' AS Date), CAST(9560 AS Numeric(20, 0)), CAST(9672 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-03-31' AS Date), CAST(9672 AS Numeric(20, 0)), CAST(9792 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-01' AS Date), CAST(9792 AS Numeric(20, 0)), CAST(9947 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-04-02' AS Date), CAST(9947 AS Numeric(20, 0)), CAST(10007 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-03' AS Date), CAST(10007 AS Numeric(20, 0)), CAST(10095 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-04' AS Date), CAST(10095 AS Numeric(20, 0)), CAST(10095 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-05' AS Date), CAST(10095 AS Numeric(20, 0)), CAST(10095 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-04-06' AS Date), CAST(10095 AS Numeric(20, 0)), CAST(10200 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-07' AS Date), CAST(10200 AS Numeric(20, 0)), CAST(10289 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-08' AS Date), CAST(10289 AS Numeric(20, 0)), CAST(10409 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-09' AS Date), CAST(10409 AS Numeric(20, 0)), CAST(10515 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-04-10' AS Date), CAST(10515 AS Numeric(20, 0)), CAST(10620 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-11' AS Date), CAST(10620 AS Numeric(20, 0)), CAST(10725 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-12' AS Date), CAST(10725 AS Numeric(20, 0)), CAST(10794 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-13' AS Date), CAST(10794 AS Numeric(20, 0)), CAST(10904 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-14' AS Date), CAST(10904 AS Numeric(20, 0)), CAST(11024 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-04-15' AS Date), CAST(11024 AS Numeric(20, 0)), CAST(11135 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-04-16' AS Date), CAST(11135 AS Numeric(20, 0)), CAST(11229 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-17' AS Date), CAST(11229 AS Numeric(20, 0)), CAST(11322 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-18' AS Date), CAST(11322 AS Numeric(20, 0)), CAST(11438 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-19' AS Date), CAST(11438 AS Numeric(20, 0)), CAST(11549 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-04-20' AS Date), CAST(11549 AS Numeric(20, 0)), CAST(11670 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-21' AS Date), CAST(11670 AS Numeric(20, 0)), CAST(11787 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-22' AS Date), CAST(11787 AS Numeric(20, 0)), CAST(11894 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-23' AS Date), CAST(11894 AS Numeric(20, 0)), CAST(12007 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-04-24' AS Date), CAST(12007 AS Numeric(20, 0)), CAST(12108 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-25' AS Date), CAST(12108 AS Numeric(20, 0)), CAST(12232 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-26' AS Date), CAST(12232 AS Numeric(20, 0)), CAST(12329 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-04-27' AS Date), CAST(12329 AS Numeric(20, 0)), CAST(12406 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-04-28' AS Date), CAST(12406 AS Numeric(20, 0)), CAST(12510 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-04-29' AS Date), CAST(12510 AS Numeric(20, 0)), CAST(12590 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-04-30' AS Date), CAST(12590 AS Numeric(20, 0)), CAST(12651 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-05-01' AS Date), CAST(12651 AS Numeric(20, 0)), CAST(12742 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-05-02' AS Date), CAST(12742 AS Numeric(20, 0)), CAST(12873 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-05-03' AS Date), CAST(12873 AS Numeric(20, 0)), CAST(13023 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-05-04' AS Date), CAST(13023 AS Numeric(20, 0)), CAST(13143 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-05-05' AS Date), CAST(13143 AS Numeric(20, 0)), CAST(13240 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-05-06' AS Date), CAST(13240 AS Numeric(20, 0)), CAST(13328 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-05-07' AS Date), CAST(13328 AS Numeric(20, 0)), CAST(13427 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-05-08' AS Date), CAST(13427 AS Numeric(20, 0)), CAST(13495 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-05-09' AS Date), CAST(13495 AS Numeric(20, 0)), CAST(13585 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-05-10' AS Date), CAST(13585 AS Numeric(20, 0)), CAST(13705 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-05-11' AS Date), CAST(13705 AS Numeric(20, 0)), CAST(13813 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 1, CAST(N'2021-05-12' AS Date), CAST(13813 AS Numeric(20, 0)), CAST(13942 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-05-13' AS Date), CAST(13942 AS Numeric(20, 0)), CAST(14048 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 7, CAST(N'2021-05-14' AS Date), CAST(14048 AS Numeric(20, 0)), CAST(14155 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 10, CAST(N'2021-05-15' AS Date), CAST(14155 AS Numeric(20, 0)), CAST(14254 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 14, CAST(N'2021-05-16' AS Date), CAST(14254 AS Numeric(20, 0)), CAST(14337 AS Numeric(20, 0)));

INSERT INTO CarMileage (CarID, EmpID, "Date", CounterStart, CounterEnd) VALUES (5, 5, CAST(N'2021-05-17' AS Date), CAST(14337 AS Numeric(20, 0)), CAST(14458 AS Numeric(20, 0)));

