
-- TRIGGER Insert_Carhistory ******************************************************************************

CREATE OR REPLACE TRIGGER Insert_Carhistory 
AFTER INSERT on CarMileage
for each row
DECLARE COUNTER_CYCLE INT; -- CounterCycleTechInspect VALUE
        COUNTER_CYCLE_OFFSET INT;
        COUNTER_CURRENT INT; -- The current value of the kilometre counter
        IFEXIST_ACTION_7 INT; 
        IFEXIST_ACTION_7_COMPLETED INT; 
        COUNTER_ACTION_7 INT; 
        STATUS_ACTION_7 VARCHAR2(20); 
        COUNTER_ACTION_7_COMPLETED INT := 0; 
BEGIN
	SELECT CounterCycleTechInspect, CounterCycleTechInspectOffset  INTO COUNTER_CYCLE, COUNTER_CYCLE_OFFSET 
    FROM CAR 
    WHERE CarID = :new.carid;
    COUNTER_CURRENT := :new.counterend ;
    dbms_output.put_line('COUNTER_CURRENT=' || COUNTER_CURRENT) ;
    dbms_output.put_line('COUNTER_CYCLE=' || COUNTER_CYCLE) ;
    dbms_output.put_line('COUNTER_CYCLE_OFFSET=' || COUNTER_CYCLE_OFFSET) ; 


	IF COUNTER_CYCLE - COUNTER_CYCLE_OFFSET < COUNTER_CURRENT THEN
        IFEXIST_ACTION_7_COMPLETED  := 0; 
        SELECT COUNT(1) INTO IFEXIST_ACTION_7_COMPLETED FROM CARHISTORY WHERE Statusid = 2 AND CARID = :NEW.CARID AND ActionID = 7;
        dbms_output.put_line('IFEXIST_ACTION_7_COMPLETED=' || IFEXIST_ACTION_7_COMPLETED) ;

        IF IFEXIST_ACTION_7_COMPLETED <> 0 THEN
            SELECT MAX(COUNTER) INTO COUNTER_ACTION_7_COMPLETED  FROM CarHistory WHERE Statusid = 2 AND CARID = :NEW.CARID AND ActionID = 7 ;
        END IF;

		dbms_output.put_line('COUNTER_ACTION_7_COMPLETED=' || COUNTER_ACTION_7_COMPLETED) ;
        dbms_output.put_line('COUNTER_CURRENT - COUNTER_ACTION_7_COMPLETED=' || (COUNTER_CURRENT - COUNTER_ACTION_7_COMPLETED)) ;
        dbms_output.put_line('COUNTER_CYCLE - COUNTER_CYCLE_OFFSET=' || (COUNTER_CYCLE - COUNTER_CYCLE_OFFSET)) ;
        dbms_output.put_line((COUNTER_CURRENT - COUNTER_ACTION_7_COMPLETED)  || ' >= ' || (COUNTER_CYCLE - COUNTER_CYCLE_OFFSET)) ;
		IF COUNTER_CURRENT - COUNTER_ACTION_7_COMPLETED >= COUNTER_CYCLE - COUNTER_CYCLE_OFFSET THEN
            COUNTER_ACTION_7 := 0;
            IFEXIST_ACTION_7 := 0;
            STATUS_ACTION_7 := '';
            SELECT COUNT(1) INTO IFEXIST_ACTION_7 FROM carhistory WHERE ActionID = 7 AND  CARID = :NEW.CARID;
            IF IFEXIST_ACTION_7 <> 0 THEN
                SELECT  MAX(COUNTER) INTO COUNTER_ACTION_7  FROM CarHistory WHERE ActionID = 7 AND  CARID = :NEW.CARID;
                dbms_output.put_line('COUNTER_ACTION_7=' ||COUNTER_ACTION_7) ;
                SELECT Statusid INTO STATUS_ACTION_7 from CarHistory where ActionID = 7 and counter = COUNTER_ACTION_7 AND  CARID = :NEW.CARID;
            END IF;

			dbms_output.put_line('STATUS_ACTION_7=' || STATUS_ACTION_7) ;

			IF IFEXIST_ACTION_7 = 0 
                OR (COUNTER_CURRENT - COUNTER_ACTION_7 > (COUNTER_CYCLE_OFFSET * 2) and STATUS_ACTION_7 <> 2 )
                OR (COUNTER_CURRENT - COUNTER_ACTION_7 > COUNTER_CYCLE - COUNTER_CYCLE_OFFSET  and STATUS_ACTION_7 = 2 )THEN    
				INSERT INTO CarHistory (CarID, empid, counter, ActionID, Statusid, "Date")
                            VALUES (:new.carid, :new.empid, COUNTER_CURRENT, 7, 1, '2022-10-27'); -- In production version of this code, don't forget to change the date to sysdate or getdate 
                dbms_output.put_line('A new record has been added to the table carHistory') ;            
			END IF;
		END IF;
	END IF;
END Insert_Carhistory;

/
-- TRIGGER t_ActivityLog_ACTIONTYPE******************************************************************************

CREATE OR REPLACE TRIGGER t_ActivityLog_ACTIONTYPE
AFTER INSERT OR UPDATE OR DELETE ON ACTIONTYPE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'ACTIONTYPE');
END;


/
-- TRIGGER t_ActivityLog_CAR ******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_CAR
AFTER INSERT OR UPDATE OR DELETE ON CAR
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete'; 
    END IF; 
	 P_UpdateActivityLog(Operation,'CAR');     
END;

/
-- TRIGGER t_ActivityLog_CARHISTORY ******************************************************************************



CREATE OR REPLACE TRIGGER t_ActivityLog_CARHISTORY
AFTER INSERT OR UPDATE OR DELETE ON CARHISTORY
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'CARHISTORY');
END;

/
-- TRIGGER t_ActivityLog_CARHISTORYSTATUS ******************************************************************************

CREATE OR REPLACE TRIGGER t_ActivityLog_CARHISTORYSTATUS
AFTER INSERT OR UPDATE OR DELETE ON CARHISTORYSTATUS
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'CARHISTORYSTATUS');
END;


/
-- TRIGGER t_ActivityLog_CARMILEAGE******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_CARMILEAGE
AFTER INSERT OR UPDATE OR DELETE ON CARMILEAGE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'CARMILEAGE');
END;

/
-- TRIGGER t_ActivityLog_CONTRACTTYPE ******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_CONTRACTTYPE
AFTER INSERT OR UPDATE OR DELETE ON CONTRACTTYPE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'CONTRACTTYPE');
END;

/

-- TRIGGER t_ActivityLog_EMPLOYEE ******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_EMPLOYEE
AFTER INSERT OR UPDATE OR DELETE ON EMPLOYEE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 
	P_UpdateActivityLog(Operation,'EMPLOYEE');
END;

/
-- TRIGGER t_ActivityLog_LOCATION ******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_LOCATION
AFTER INSERT OR UPDATE OR DELETE ON LOCATION
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 
	 P_UpdateActivityLog(Operation,'LOCATION');  
END;

/
-- TRIGGER t_ActivityLog_PAYMENTCYCLE******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_PAYMENTCYCLE
AFTER INSERT OR UPDATE OR DELETE ON PAYMENTCYCLE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'PAYMENTCYCLE');
END;

/
-- TRIGGER t_ActivityLog_RESTAURANT******************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_RESTAURANT
AFTER INSERT OR UPDATE OR DELETE ON RESTAURANT
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 
	P_UpdateActivityLog(Operation,'RESTAURANT');
END;

/

-- TRIGGER t_ActivityLog_ROLE  *****************************************************************************


CREATE OR REPLACE TRIGGER t_ActivityLog_ROLE
AFTER INSERT OR UPDATE OR DELETE ON ROLE
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'ROLE');
END;

/

-- TRIGGER t_ActivityLog_STATUS *****************************************************************************



CREATE OR REPLACE TRIGGER t_ActivityLog_STATUS
AFTER INSERT OR UPDATE OR DELETE ON STATUS
FOR EACH ROW
DECLARE 
    Operation VARCHAR2(10); 
BEGIN 
    IF INSERTING THEN
            Operation := 'Insert';
    ELSIF UPDATING THEN
            Operation := 'Update';
    ELSIF DELETING THEN
            Operation := 'Delete';
    END IF; 

	 P_UpdateActivityLog(Operation,'STATUS');
END;