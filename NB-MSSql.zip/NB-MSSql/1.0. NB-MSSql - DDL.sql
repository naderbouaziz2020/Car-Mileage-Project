
/****** Object:  Table [dbo].[ActionType]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ActionType](
	[ActionID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](100) NULL,
 CONSTRAINT [ActionType_pk] PRIMARY KEY CLUSTERED 
(
	[ActionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ActivityLog]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ActivityLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DateTimeStamp] [datetime] NOT NULL,
	[UserName] [varchar](50) NOT NULL,
	[ActivityType] [varchar](10) NOT NULL,
	[TableName] [varchar](40) NOT NULL,
 CONSTRAINT [ActivityLog_pk] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Car]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Car](
	[CarID] [int] IDENTITY(1,1) NOT NULL,
	[RestID] [int] NOT NULL,
	[Brand] [varchar](20) NOT NULL,
	[Model] [varchar](20) NOT NULL,
	[RegistrationNumber] [varchar](20) NOT NULL,
	[StartUse] [date] NOT NULL,
	[CounterLimit] [numeric](10, 0) NOT NULL,
	[CounterCycleTechInspect] [numeric](10, 0) NOT NULL,
	[CounterCycleTechInspectOffset] [numeric](10, 0) NOT NULL,
	[PlannedDiagnostics] [date] NOT NULL,
	[StatusID] [int] NOT NULL,
 CONSTRAINT [Car_pk] PRIMARY KEY CLUSTERED 
(
	[CarID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarHistory]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarHistory](
	[CarID] [int] NOT NULL,
	[Date] [date] NOT NULL,
	[EmpID] [int] NOT NULL,
	[Counter] [numeric](10, 0) NOT NULL,
	[ActionID] [int] NOT NULL,
	[StatusID] [int] NOT NULL,
 CONSTRAINT [CarHistory_pk] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[CarID] ASC,
	[ActionID] ASC,
	[Counter] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarHistoryStatus]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarHistoryStatus](
	[StatusID] [int] NOT NULL,
	[StatusName] [varchar](20) NOT NULL,
 CONSTRAINT [CarHistoryStatus_pk] PRIMARY KEY CLUSTERED 
(
	[StatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarMileage]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarMileage](
	[CarID] [int] NOT NULL,
	[EmpID] [int] NOT NULL,
	[Date] [date] NOT NULL,
	[CounterStart] [numeric](20, 0) NOT NULL,
	[CounterEnd] [numeric](20, 0) NOT NULL,
 CONSTRAINT [CarMileage_pk] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[CarID] ASC,
	[EmpID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ContractType]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ContractType](
	[ContractTypeID] [int] NOT NULL,
	[ContractType] [varchar](50) NOT NULL,
 CONSTRAINT [PK_ContractType] PRIMARY KEY CLUSTERED 
(
	[ContractTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[EmpID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[RoleID] [int] NOT NULL,
	[ContractTypeID] [int] NOT NULL,
	[StartContract] [date] NOT NULL,
	[EndContract] [date] NULL,
	[UnitSalary] [numeric](10, 2) NOT NULL,
	[LocID] [int] NOT NULL,
	[PaymentCycleID] [char](1) NOT NULL,
	[StatusID] [int] NOT NULL,
 CONSTRAINT [Employee_pk] PRIMARY KEY CLUSTERED 
(
	[EmpID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Location]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Location](
	[LocID] [int] IDENTITY(1,1) NOT NULL,
	[RestID] [int] NOT NULL,
	[StreetName] [varchar](30) NOT NULL,
	[StreetNumber] [varchar](10) NOT NULL,
	[PostalCode] [varchar](10) NOT NULL,
	[City] [varchar](30) NOT NULL,
	[Phone] [varchar](20) NOT NULL,
	[StatusID] [int] NOT NULL,
 CONSTRAINT [Location_pk] PRIMARY KEY CLUSTERED 
(
	[LocID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentCycle]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentCycle](
	[PaymentCycleID] [char](1) NOT NULL,
	[PaymentCycle] [varchar](20) NOT NULL,
 CONSTRAINT [PK_PaymentCycle] PRIMARY KEY CLUSTERED 
(
	[PaymentCycleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Restaurant]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Restaurant](
	[RestID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](20) NOT NULL,
	[EmpNumber] [int] NOT NULL,
	[CarNumber] [int] NOT NULL,
	[LocationNumber] [int] NOT NULL,
	[Website] [varchar](50) NOT NULL,
	[Email] [varchar](100) NOT NULL,
	[Phone] [varchar](20) NOT NULL,
 CONSTRAINT [Restaurant_pk] PRIMARY KEY CLUSTERED 
(
	[RestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Role]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Role](
	[RoleID] [int] NOT NULL,
	[RoleName] [varchar](50) NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Status]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Status](
	[StatusID] [int] NOT NULL,
	[StatusName] [varchar](10) NOT NULL,
 CONSTRAINT [Status_pk] PRIMARY KEY CLUSTERED 
(
	[StatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


ALTER TABLE [dbo].[Car] ADD  DEFAULT ((500)) FOR [CounterCycleTechInspectOffset]
GO
ALTER TABLE [dbo].[Car] ADD  DEFAULT ((1)) FOR [StatusID]
GO
ALTER TABLE [dbo].[CarHistory] ADD  DEFAULT ((1)) FOR [StatusID]
GO
ALTER TABLE [dbo].[Employee] ADD  DEFAULT ((1)) FOR [StatusID]
GO
ALTER TABLE [dbo].[Location] ADD  DEFAULT ((1)) FOR [StatusID]
GO
ALTER TABLE [dbo].[Car]  WITH CHECK ADD  CONSTRAINT [FK_Car_Restaurant] FOREIGN KEY([RestID])
REFERENCES [dbo].[Restaurant] ([RestID])
GO
ALTER TABLE [dbo].[Car] CHECK CONSTRAINT [FK_Car_Restaurant]
GO
ALTER TABLE [dbo].[Car]  WITH CHECK ADD  CONSTRAINT [FK_Car_Status] FOREIGN KEY([StatusID])
REFERENCES [dbo].[Status] ([StatusID])
GO
ALTER TABLE [dbo].[Car] CHECK CONSTRAINT [FK_Car_Status]
GO
ALTER TABLE [dbo].[CarHistory]  WITH CHECK ADD  CONSTRAINT [CarHistory_ActionType] FOREIGN KEY([ActionID])
REFERENCES [dbo].[ActionType] ([ActionID])
GO
ALTER TABLE [dbo].[CarHistory] CHECK CONSTRAINT [CarHistory_ActionType]
GO
ALTER TABLE [dbo].[CarHistory]  WITH CHECK ADD  CONSTRAINT [CarHistory_Car] FOREIGN KEY([CarID])
REFERENCES [dbo].[Car] ([CarID])
GO
ALTER TABLE [dbo].[CarHistory] CHECK CONSTRAINT [CarHistory_Car]
GO
ALTER TABLE [dbo].[CarHistory]  WITH CHECK ADD  CONSTRAINT [CarHistory_Employee] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employee] ([EmpID])
GO
ALTER TABLE [dbo].[CarHistory] CHECK CONSTRAINT [CarHistory_Employee]
GO
ALTER TABLE [dbo].[CarHistory]  WITH CHECK ADD  CONSTRAINT [FK_CarHistory_CarHistoryStatus] FOREIGN KEY([StatusID])
REFERENCES [dbo].[CarHistoryStatus] ([StatusID])
GO
ALTER TABLE [dbo].[CarHistory] CHECK CONSTRAINT [FK_CarHistory_CarHistoryStatus]
GO
ALTER TABLE [dbo].[CarMileage]  WITH CHECK ADD  CONSTRAINT [CarMileage_Car] FOREIGN KEY([CarID])
REFERENCES [dbo].[Car] ([CarID])
GO
ALTER TABLE [dbo].[CarMileage] CHECK CONSTRAINT [CarMileage_Car]
GO
ALTER TABLE [dbo].[CarMileage]  WITH CHECK ADD  CONSTRAINT [CarMileage_Employee] FOREIGN KEY([EmpID])
REFERENCES [dbo].[Employee] ([EmpID])
GO
ALTER TABLE [dbo].[CarMileage] CHECK CONSTRAINT [CarMileage_Employee]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [Employee_Location] FOREIGN KEY([LocID])
REFERENCES [dbo].[Location] ([LocID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [Employee_Location]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_ContractType] FOREIGN KEY([ContractTypeID])
REFERENCES [dbo].[ContractType] ([ContractTypeID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_ContractType]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_PaymentCycle] FOREIGN KEY([PaymentCycleID])
REFERENCES [dbo].[PaymentCycle] ([PaymentCycleID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_PaymentCycle]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Role] FOREIGN KEY([RoleID])
REFERENCES [dbo].[Role] ([RoleID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Role]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Status] FOREIGN KEY([StatusID])
REFERENCES [dbo].[Status] ([StatusID])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Status]
GO
ALTER TABLE [dbo].[Location]  WITH CHECK ADD  CONSTRAINT [FK_Location_Status] FOREIGN KEY([StatusID])
REFERENCES [dbo].[Status] ([StatusID])
GO
ALTER TABLE [dbo].[Location] CHECK CONSTRAINT [FK_Location_Status]
GO
ALTER TABLE [dbo].[Location]  WITH CHECK ADD  CONSTRAINT [Location_Restaurant] FOREIGN KEY([RestID])
REFERENCES [dbo].[Restaurant] ([RestID])
GO
ALTER TABLE [dbo].[Location] CHECK CONSTRAINT [Location_Restaurant]
GO

