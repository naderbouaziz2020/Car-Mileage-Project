
/****** Object:  StoredProcedure [dbo].[p_UpdateActivityLog]    Script Date: 2022-01-31 19:32:12 ******/
CREATE OR ALTER PROCEDURE [dbo].[p_UpdateActivityLog] 
@Operation varchar(7), @tableName varchar(40)
AS
BEGIN
	INSERT INTO ActivityLog VALUES (GETDATE(), SYSTEM_USER, @Operation, @tableName );
END;

GO


/****** Object:  StoredProcedure [dbo].[p_UpdateRestaurantData]    Script Date: 2022-01-31 17:41:28 ******/
CREATE OR ALTER PROCEDURE [dbo].[p_UpdateRestaurantData]
@RestID int
AS
BEGIN
	DECLARE @EmpN INT, @CarN INT, @LocN INT;
	SELECT @EmpN = COUNT(1) FROM Employee;
	SELECT @CarN = COUNT(1) FROM Car;
	SELECT @LocN = COUNT(1) FROM Location;
	UPDATE Restaurant SET EmpNumber = @EmpN , CarNumber = @CarN, LocationNumber = @LocN WHERE RestID = @RestID;
	PRINT('Table [Restaurant] updated');
END;
GO


/****** Object:  StoredProcedure [p_DisplayAllEmpWithGivenRole]    Script Date: 2022-01-30 19:36:36 ******/
CREATE OR ALTER PROCEDURE [p_DisplayAllEmpWithGivenRole] 
@P_ROLE INT
AS
BEGIN

DECLARE @V_EMPID INT, @V_EMPNAME VARCHAR(30), @V_ROLE INT, @V_LOCID INT, @V_ROLENAME VARCHAR(50), @V_LOCADDRESS VARCHAR(30);

SELECT @V_ROLENAME = RoleName from Role where RoleID = @P_ROLE
Print ('===================================================')
Print ('Below list shows all employees with role "' + @V_ROLENAME + '":')
Print ('===================================================')

DECLARE EMP_CURSOR CURSOR FOR 
SELECT EmpID, Name, StreetName from Employee e
JOIN Location l
on e.LocID = l.LocID
WHERE ROLEID = @P_ROLE ;

OPEN EMP_CURSOR
	FETCH NEXT FROM EMP_CURSOR INTO @V_EMPID, @V_EMPNAME, @V_LOCADDRESS;

	WHILE @@FETCH_STATUS = 0 

		BEGIN
			PRINT('Employee ID: ' + CAST(@V_EMPID AS VARCHAR) + '; ' + @V_EMPNAME + ';  Location address: ' + @V_LOCADDRESS );
			FETCH NEXT FROM EMP_CURSOR INTO @V_EMPID, @V_EMPNAME, @V_LOCADDRESS;
		END;
		CLOSE EMP_CURSOR;
		DEALLOCATE EMP_CURSOR;

	END;
GO

