
-- TESTING trigger "Insert_CarHistory" for CarID = 5
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID


-- TEST CASE 1:
-- Adding a new CarMileage record with current counter (i.e. [CounterEnd]) value below or equal 14500 will not add a new record to CarHistory table
-- because the current counter value is lower than [CounterCycleTechInspect]-[CounterCycleTechInspectOffset] , i.e. 14499 < 15000 - 500
INSERT INTO CarMileage values (5, 7, '2021-05-19', 14458, 14499)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 1 completed')



-- TEST CASE 2:
-- Adding a new CarMileage record with current counter (i.e. [CounterEnd]) value above 14500 will add a new record 
-- with ActionID = 7 and StatusID = 1 (i.e. "In progress") to CarHistory table
-- because the current counter value is higher than [CounterCycleTechInspect]-[CounterCycleTechInspectOffset] , i.e. 14561 > 15000 - 500
-- and it's time to reserve Tech Inspection visit at car repair/service center
INSERT INTO CarMileage values (5, 7, '2021-05-20', 14499, 14561)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 2 completed')


-- TEST CASE 3:
-- After creating a record with ActionID = 7 and StatusID = 1 (i.e. "In progress") to CarHistory table the trigger will 
-- allow to add new CarMileage records without other tasks/actions to be added to CarHistory table until the car counter reaches the value higher than 15561 (=14561+1000)
-- so adding the following CarMileage records will not add new record to CarHistory table
INSERT INTO CarMileage values (5, 7, '2021-05-21', 14561, 14885)
INSERT INTO CarMileage values (5, 7, '2021-05-22', 14885, 15120)
INSERT INTO CarMileage values (5, 7, '2021-05-23', 15120, 15350)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 3 completed')


-- TEST CASE 4:
-- When the car counter exceeds the value of 15561 (=14561+1000) and the status of the latest record with ActionID = 7 in the CarHistory table is still "In progress"
-- then another record with ActionID = 7 and StatusID = 1 (i.e. "In progress") will be added to CarHistory table
-- in order to remind the User/Owner of the restaurant that Tech Inspection of the car is still not done
INSERT INTO CarMileage values (5, 7, '2021-05-24', 15350, 15650)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 4 completed')


-- Preparation for TEST CASE 5:
-- The status should be changed to 'Completed' in the latest CarHistory record with ActionID = 7 
UPDATE CarHistory SET StatusID = 2
WHERE CarID = 5 and ActionID = 7 and Counter = (SELECT MAX(Counter) FROM CarHistory WHERE CarID = 5 and ActionID = 7)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID


-- TEST CASE 5:
-- After changing the status of the latest CarHistory record with ActionID = 7 to 'Completed'
-- the system will 'wait' for the car counter value which will exceed 30150, i.e. will approach the value of the next required Tech Inspection (15650 + 15000 - 500).
-- Until that value is reached no new records will be added to CarHistory table
INSERT INTO CarMileage values (5, 7, '2021-06-01', 15650, 20120)
INSERT INTO CarMileage values (5, 7, '2021-07-01', 20120, 25230)
INSERT INTO CarMileage values (5, 7, '2021-08-01', 25230, 30099)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 5 completed')


-- TEST CASE 6:
-- When the car counter exceeds 30150, i.e. will approach the value of the next required Tech Inspection (15650 + 15000 - 500)
-- then a new record with ActionID = 7 and StatusID = 1 (i.e. "In progress") will be added to CarHistory table
INSERT INTO CarMileage values (5, 7, '2021-08-02', 30099, 30151)
SELECT * FROM [dbo].[CarMileage] order by Date desc, CarID
SELECT ch.CarID, ch.Date, ch.EmpID, ch.Counter, ch.ActionID, at.Description, ch.StatusID, chs.StatusName FROM [dbo].[CarHistory] ch 
JOIN ActionType at ON ch.ActionID = at.ActionID
JOIN CarHistoryStatus chs ON ch.StatusID = chs.StatusID
Print ('TEST CASE 6 completed')



