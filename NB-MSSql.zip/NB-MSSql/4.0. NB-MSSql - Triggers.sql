

/****** Object:  Trigger [dbo].[t_UpdateActivityLog_ActionType]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_ActionType] ON [dbo].[ActionType]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[ActionType] ENABLE TRIGGER [t_UpdateActivityLog_ActionType]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Car]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_UpdateActivityLog_Car] ON [dbo].[Car]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID


	DECLARE @RestID int;
    IF EXISTS(SELECT * FROM inserted)
		BEGIN
			SELECT @RestID = inserted.RestID from inserted
		END
    ELSE 
		BEGIN
			SELECT @RestID = deleted.RestID from deleted
		END
    

	exec p_UpdateActivityLog @Operation, @Tablename 
	
	IF @Operation <> 'Update'
	BEGIN
		PRINT('Number of car to be updated in table [Restaurant]');
		exec p_UpdateRestaurantData @RestID
	END
END;
GO
ALTER TABLE [dbo].[Car] ENABLE TRIGGER [t_UpdateActivityLog_Car]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_CarHistory]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_UpdateActivityLog_CarHistory] ON [dbo].[CarHistory]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[CarHistory] ENABLE TRIGGER [t_UpdateActivityLog_CarHistory]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_CarHistoryStatus]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_CarHistoryStatus] ON [dbo].[CarHistoryStatus]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[CarHistoryStatus] ENABLE TRIGGER [t_UpdateActivityLog_CarHistoryStatus]
GO


/****** Object:  Trigger [dbo].[Insert_CarHistory]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_Insert_CarHistory] on [dbo].[CarMileage]
AFTER INSERT 
AS
BEGIN
	DECLARE @COUNTER_CYCLE_OFFSET INT, 
			@InsertedCarID INT,
			@InsertedEmpID INT,
			@COUNTER_CYCLE INT, 
			@COUNTER_CURRENT INT, 
			@COUNTER_ACTION_7 INT,
			@STATUS_ACTION_7 varchar, 
			@COUNTER_ACTION_7_COMPLETED INT = 0, 
			@IFEXIST_ACTION_7_COMPLETED INT,
			@IFEXIST_ACTION_7 INT;

	SELECT @InsertedCarID = ins.CarID, @InsertedEmpID = ins.EmpID, @COUNTER_CURRENT = ins.CounterEnd FROM INSERTED ins;
	SELECT @COUNTER_CYCLE = CounterCycleTechInspect, @COUNTER_CYCLE_OFFSET = CounterCycleTechInspectOffset FROM CAR WHERE CarID = @InsertedCarID;
	
	Print ('@InsertedCarID = ' + cast(@InsertedCarID as varchar));
	Print ('@COUNTER_CURRENT = ' + cast(@COUNTER_CURRENT as varchar));
	Print ('@COUNTER_CYCLE = ' + cast(@COUNTER_CYCLE as varchar));
	Print ('@COUNTER_CYCLE_OFFSET = ' + cast(@COUNTER_CYCLE_OFFSET as varchar));


	IF @COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET < @COUNTER_CURRENT 
	BEGIN
		SET @IFEXIST_ACTION_7_COMPLETED = 0;
		SELECT @IFEXIST_ACTION_7_COMPLETED = COUNT(1) FROM CARHISTORY WHERE Statusid = 2 AND CARID = @InsertedCarID AND ActionID = 7;
		Print ('@IFEXIST_ACTION_7_COMPLETED = ' + cast(@IFEXIST_ACTION_7_COMPLETED as varchar))

		IF @IFEXIST_ACTION_7_COMPLETED <> 0 
		BEGIN
			SELECT @COUNTER_ACTION_7_COMPLETED = MAX(COUNTER) FROM CarHistory WHERE StatusID = 2 and CarID = @InsertedCarID AND ActionID = 7 ;
		END;
		
		Print ('@COUNTER_ACTION_7_COMPLETED = ' + cast(@COUNTER_ACTION_7_COMPLETED as varchar)) ;
        Print ('@COUNTER_CURRENT - @COUNTER_ACTION_7_COMPLETED = ' + cast((@COUNTER_CURRENT - @COUNTER_ACTION_7_COMPLETED) as varchar)) ;
        Print ('@COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET = ' + cast((@COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET) as varchar)) ;
        Print (cast((@COUNTER_CURRENT - @COUNTER_ACTION_7_COMPLETED) as varchar)  + ' >= ' + cast((@COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET) as varchar)) ;

		IF @COUNTER_CURRENT - @COUNTER_ACTION_7_COMPLETED >= @COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET
		BEGIN
			SET @COUNTER_ACTION_7 = 0;
            SET @IFEXIST_ACTION_7 = 0;
            SET @STATUS_ACTION_7 = '';

			SELECT @IFEXIST_ACTION_7 = COUNT(1)  FROM carhistory WHERE ActionID = 7 AND  CARID = @InsertedCarID;
			IF @IFEXIST_ACTION_7 <> 0 
			BEGIN
				SELECT @COUNTER_ACTION_7 = MAX(COUNTER) FROM CarHistory WHERE ActionID = 7 AND CARID = @InsertedCarID;
				Print ('@COUNTER_ACTION_7 = ' + cast(@COUNTER_ACTION_7 as varchar))
				select @STATUS_ACTION_7  = StatusID from CarHistory where ActionID = 7 and counter = @COUNTER_ACTION_7 AND CARID = @InsertedCarID;
				Print ('@STATUS_ACTION_7  = ' + cast(@STATUS_ACTION_7 as varchar))
			END;

			IF @IFEXIST_ACTION_7 = 0 
			OR (@COUNTER_CURRENT - @COUNTER_ACTION_7 > @COUNTER_CYCLE_OFFSET * 2 and @STATUS_ACTION_7 <> 2)
			OR (@COUNTER_CURRENT - @COUNTER_ACTION_7 > @COUNTER_CYCLE - @COUNTER_CYCLE_OFFSET)  and @STATUS_ACTION_7 = 2
			BEGIN
			
				INSERT INTO CarHistory (CarID, Date, EmpID, Counter, ActionID)
				VALUES (@InsertedCarID, GETDATE(), @InsertedEmpID, @COUNTER_CURRENT, 7);
				Print ('A new record has been added to the table [CarHistory]')

			END;
		END;
	END;

END;

GO
ALTER TABLE [dbo].[CarMileage] ENABLE TRIGGER [t_Insert_CarHistory]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_CarMileage]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_CarMileage] ON [dbo].[CarMileage]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[CarMileage] ENABLE TRIGGER [t_UpdateActivityLog_CarMileage]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_ContractType]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_ContractType] ON [dbo].[ContractType]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[ContractType] ENABLE TRIGGER [t_UpdateActivityLog_ContractType]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Employee]    Script Date: 2022-01-31 17:41:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_UpdateActivityLog_Employee] ON [dbo].[Employee]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID


	DECLARE @RestID int;
	DECLARE @LocID int;
    IF EXISTS(SELECT * FROM inserted)
		BEGIN
			SELECT @LocID = inserted.LocID from inserted
		END
    ELSE 
		BEGIN
			SELECT @LocID = deleted.LocID from deleted
		END

	SELECT @RestID = RestID from Location where LocID = @LocID    

	exec p_UpdateActivityLog @Operation, @Tablename 

	IF @Operation <> 'Update'
	BEGIN
		PRINT('Number of employees to be updated in table [Restaurant]');
		exec p_UpdateRestaurantData @RestID
	END
END;
GO
ALTER TABLE [dbo].[Employee] ENABLE TRIGGER [t_UpdateActivityLog_Employee]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Location]    Script Date: 2022-01-31 17:41:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_Location] ON [dbo].[Location]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID


	DECLARE @RestID int;
    IF EXISTS(SELECT * FROM inserted)
		BEGIN
			SELECT @RestID = inserted.RestID from inserted
		END
    ELSE 
		BEGIN
			SELECT @RestID = deleted.RestID from deleted
		END
    

	exec p_UpdateActivityLog @Operation, @Tablename 
	
	IF @Operation <> 'Update'
	BEGIN
		PRINT('Number of locations to be updated in table [Restaurant]');
		exec p_UpdateRestaurantData @RestID
	END
END;
GO
ALTER TABLE [dbo].[Location] ENABLE TRIGGER [t_UpdateActivityLog_Location]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_PaymentCycle]    Script Date: 2022-01-31 17:41:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_UpdateActivityLog_PaymentCycle] ON [dbo].[PaymentCycle]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[PaymentCycle] ENABLE TRIGGER [t_UpdateActivityLog_PaymentCycle]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Restaurant]    Script Date: 2022-01-31 17:41:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_Restaurant] ON [dbo].[Restaurant]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[Restaurant] ENABLE TRIGGER [t_UpdateActivityLog_Restaurant]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Role]    Script Date: 2022-01-31 17:41:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[t_UpdateActivityLog_Role] ON [dbo].[Role]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[Role] ENABLE TRIGGER [t_UpdateActivityLog_Role]
GO


/****** Object:  Trigger [dbo].[t_UpdateActivityLog_Status]    Script Date: 2022-01-31 17:41:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[t_UpdateActivityLog_Status] ON [dbo].[Status]
AFTER INSERT, UPDATE, DELETE 
AS
BEGIN
	DECLARE @Operation varchar(7) = 
    CASE WHEN EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted) 
        THEN 'Update'
    WHEN EXISTS(SELECT * FROM inserted) 
        THEN 'Insert'
    WHEN EXISTS(SELECT * FROM deleted)
        THEN 'Delete'
    ELSE 
        NULL --Unknown
    END;
	SET NOCOUNT ON; 
    declare @TableName sysname
    select @TableName =  object_name(parent_id) 
    from sys.triggers where object_id = @@PROCID

	exec p_UpdateActivityLog @Operation, @Tablename 
END;
GO
ALTER TABLE [dbo].[Status] ENABLE TRIGGER [t_UpdateActivityLog_Status]
GO
