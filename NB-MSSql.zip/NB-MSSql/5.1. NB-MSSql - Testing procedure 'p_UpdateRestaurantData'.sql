
/*	TESTING procedure 'p_UpdateRestaurantData'
	The procedure updates the number of employees, cars and location any time 
	when the number of records in relevant tables [Employee], [Car], [Location] changes
	The procedure is executed by triggers.
*/
SELECT * FROM Restaurant
SELECT * FROM Employee
SELECT * FROM Car
SELECT * FROM Location


-- TEST CASE 1: Add new Employee
SET IDENTITY_INSERT [dbo].[Employee] ON 
INSERT [dbo].[Employee] ([EmpID], [Name], [RoleID], [ContractTypeID], [StartContract], [EndContract], [UnitSalary], [LocID], [PaymentCycleID], [StatusID]) 
VALUES (15, N'Spider Man 2', 3, 1, CAST(N'2017-05-10' AS Date), NULL, 4000 , 1, N'M', 1)
SET IDENTITY_INSERT [dbo].[Employee] off
SELECT * FROM Employee
SELECT * FROM Restaurant

-- TEST CASE 2: Delete 1 Employee
DELETE FROM Employee WHERE EmpId = 15
SELECT * FROM Employee
SELECT * FROM Restaurant


-- TEST CASE 3: Add new Car
SET IDENTITY_INSERT [dbo].[Car] ON 
INSERT [dbo].[Car] ([CarID], [RestID], [Brand], [Model], [RegistrationNumber], [StartUse], [CounterLimit], [CounterCycleTechInspect], [CounterCycleTechInspectOffset], [PlannedDiagnostics], [StatusID]) 
VALUES (8, 1, N'Toyota', N'Aygo', N'WZ458WZ', CAST(N'2017-03-09' AS Date), CAST(75000 AS Numeric(10, 0)), CAST(15000 AS Numeric(10, 0)), CAST(500 AS Numeric(10, 0)), CAST(N'2020-01-26' AS Date), 0)
SET IDENTITY_INSERT [dbo].[Car] off
SELECT * FROM Car
SELECT * FROM Restaurant

-- TEST CASE 4: Delete 1 Car
DELETE FROM Car WHERE CarID = 8
SELECT * FROM Car
SELECT * FROM Restaurant


-- TEST CASE 5: Add new Location
SET IDENTITY_INSERT [dbo].[Location] ON 
INSERT [dbo].[Location] ([LocID], [RestID], [StreetName], [StreetNumber], [PostalCode], [City], [Phone], [StatusID]) 
VALUES (4, 1, N'Gara�owa', N'9', N'01-123', N'Warsaw', N'+48 987 654 321', 1)
SET IDENTITY_INSERT [dbo].[Location] Off
SELECT * FROM Location
SELECT * FROM Restaurant

-- TEST CASE 6: Delete 1 Location
DELETE FROM Location WHERE LocID = 4
SELECT * FROM Location
SELECT * FROM Restaurant