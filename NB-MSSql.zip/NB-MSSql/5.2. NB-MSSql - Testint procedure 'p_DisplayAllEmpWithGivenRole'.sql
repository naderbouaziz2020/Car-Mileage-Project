-- TESTING procedure [p_DisplayAllEmpWithGivenRole]
-- This procedure helps to quickly get a printed list of all employees with given role
-- Please check 'Messages' tab
/*
	select * from Role
	----------------------
	|RoleID	|	RoleName |
	----------------------
	|1		|	Manager  |
	|2		|	Cook     |
	|3		|	Driver	 |
	|4		|	Cashier  |
	----------------------

	Please check 'Messages' tab
 */


-- Assign a value to @RoleID
DECLARE @RoleID INT = 1;

EXEC p_DisplayAllEmpWithGivenRole @RoleID

SELECT e.EmpID, e.Name as 'Employee name', r.RoleName as 'Role name', l.StreetName as 'Location address'
from Employee e
	join Location l
	on e.LocID = l.LocID
	join Role r
	on e.RoleID = r.RoleID
where r.RoleID = @RoleID
